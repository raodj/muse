#ifndef SIMSTREAM_CPP
#define	SIMSTREAM_CPP

#include "SimStream.h"
using namespace muse;

SimStream::SimStream(){}

SimStream::~SimStream(){}

#endif
