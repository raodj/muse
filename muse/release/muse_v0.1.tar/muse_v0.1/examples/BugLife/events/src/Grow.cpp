#ifndef _GROW_CPP
#define _GROW_CPP

#include "Grow.h"

Grow::Grow(AgentID receiverID, Time receiveTime, BugEventType e_type) : BugEvent(receiverID, receiveTime, e_type ), size(1) {}

#endif
