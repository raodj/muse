/* 
 * File:   ClockExample.cpp
 * Author: gebremr
 *
 * Created on December 10, 2008, 9:44 PM
 */

#include <iostream>
#include "Simulation.h"
#include "Agent.h"
#include "State.h"

using namespace muse;
using namespace std;

/*
 * 
 */
int main() {

    cout << "Clock Example via MUSE API" << endl;
    Simulation &kernel = Simulation::getSimulator();
    
    cout << "Kernel address: " << &kernel << endl;
    return (EXIT_SUCCESS);
}

