var searchData=
[
  ['infectionstate_3204',['InfectionState',['../Person_8h.html#a26ccfeaa34124d4125b297b337c8643b',1,'Person.h']]]
];
