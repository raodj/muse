var searchData=
[
  ['eventtype_3202',['EventType',['../EpidemicEvent_8h.html#a2628ea8d12e8b2563c32f05dc7fff6fa',1,'EpidemicEvent.h']]]
];
