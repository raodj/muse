var searchData=
[
  ['numamemorymanager_2ecpp_1917',['NumaMemoryManager.cpp',['../NumaMemoryManager_8cpp.html',1,'']]],
  ['numamemorymanager_2eh_1918',['NumaMemoryManager.h',['../NumaMemoryManager_8h.html',1,'']]]
];
