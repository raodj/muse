var searchData=
[
  ['dead_1667',['Dead',['../classDead.html',1,'']]],
  ['defaultsimulation_1668',['DefaultSimulation',['../classDefaultSimulation.html',1,'']]],
  ['diseasemodel_1669',['DiseaseModel',['../classDiseaseModel.html',1,'']]]
];
