var searchData=
[
  ['arrival_3211',['ARRIVAL',['../EpidemicEvent_8h.html#a2628ea8d12e8b2563c32f05dc7fff6faae5b44f857c1441223fccbf7fc11c86fb',1,'EpidemicEvent.h']]],
  ['asymptomatic_3212',['ASYMPTOMATIC',['../Person_8h.html#a26ccfeaa34124d4125b297b337c8643ba15f6804b67fed535c4483487729b3af4',1,'Person.h']]]
];
