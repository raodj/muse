#ifndef _AGENT_NAME_HERE_CPP
#define	_AGENT_NAME_HERE_CPP

#include "AGENT_NAME_HERE.h"
#include "Event.h"


using namespace std;

AGENT_NAME_HERE::AGENT_NAME_HERE(AgentID& id, State* state) : Agent(id,state){}

void
AGENT_NAME_HERE::initialize() throw (std::exception){

}//end initialize

void
AGENT_NAME_HERE::executeTask(const EventContainer* events){

}//end executeTask

void
AGENT_NAME_HERE::finalize() {
    
}//end finalize
#endif 

