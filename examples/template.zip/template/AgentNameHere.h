/* 
  This is a template to quickly get going with development
  The usuless task of setting up the bases classes is done for you.
  Just change names around and get to the good part.
 */

#ifndef _AGENT_NAME_HERE_H
#define	_AGENT_NAME_HERE_H

#include "Agent.h"
#include "State.h"
using namespace muse;

class AGENT_NAME_HERE : public Agent {

public:
    AGENT_NAME_HERE(AgentID &, State *);

    void initialize() throw (std::exception);

    void executeTask(const EventContainer* events);

    void finalize();

};

#endif	/* _AGENT_NAME_HERE_H */

