/* 
 * File:   Event.h
 * Author: gebremr
 *
 * Created on November 13, 2008, 11:11 PM
 */

#ifndef _EVENT_H
#define	_EVENT_H

#include "DataTypes.h"
#include <set>

BEGIN_NAMESPACE(muse);

class Event {
    
   
public:
   
     
    explicit Event(const AgentID & senderID,const AgentID & receiverID,
                   const Time & sentTime, const Time & receiveTime);
    
    const AgentID & getSenderAgentID();
    
    const AgentID & getReceiverAgentID();
    
    const Time & getSentTime();
    
    const Time & getReceiveTime();
    
 
protected:
    AgentID senderAgentID, receiverAgentID;
    Time sentTime,receiveTime;
};

END_NAMESPACE(muse);
 //typedef std::set<Event*> EventContainer;
#endif	/* _EVENT_H */

