#ifndef _AGENT_H
#include "Agent.h"
#endif
using namespace muse;

Agent::Agent(AgentID & id) : _myID(id), _LVT(0) {}

void 
Agent::initialize(){
    
}

void 
Agent::executeTask(EventContainer * events){
    
}

void 
Agent::finalize(){
    
}


bool 
Agent::scheduleEvent( Event *e){
    return (SimulationKernel::getSimulator()).scheduleEvent(e);
}

const AgentID& Agent::getAgentID(){
    return _myID;
}
