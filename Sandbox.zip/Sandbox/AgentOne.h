/* 
 * File:   AgentOne.h
 * Author: gebremr
 *
 * Created on November 17, 2008, 10:04 AM
 */

#ifndef _AGENTONE_H
#define	_AGENTONE_H

#include "Agent.h"
#include "DataTypes.h"

using namespace muse;

class AgentOne : public Agent {
    
public:
    AgentOne(AgentID &);
     void initialize();
     void finalize();
     void executeTask(EventContainer *);
};

#endif	/* _AGENTONE_H */

