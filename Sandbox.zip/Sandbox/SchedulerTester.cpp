/* 
 * File:   SchedulerTester.cpp
 * Author: gebremr
 *
 * Created on November 14, 2008, 2:45 PM
 */

#include "SimulationKernel.h"


#include "SimulationKernel.h"


#include <set>
#include <iostream>
#include <stdlib.h>
#include "Scheduler.h"
#include "DataTypes.h"
#include "SimulationKernel.h"
#include "AgentOne.h"
#include "AgentTwo.h"
#include "Event.h"

using namespace muse;
using namespace std;
/*
 * 
 */
int main(int argc, char** argv) {
    
    // dummy agents list, we will get this from the simulation kernel
     AgentID one=1, two=2, three=3, four=4;
     Time t1 = 1, t2=2, t3=3,t33 = 3, t100=100;
 
     //create a scheduler 
     //Scheduler scheduler;
     //scheduler.addAgentToScheduler(one);
     //scheduler.addAgentToScheduler(two);
     
     //cout << "schedule[4] = " << (scheduler.schedule[four] == NULL)<< endl;
     
     std::cout <<"\n\nProof that only one instance of Kernel is alive" << std::endl;
     SimulationKernel & kernel = SimulationKernel::getSimulator();
     std::cout <<"\n\nKernel Address: " << &kernel << std::endl;
     Time start=100;
     kernel.setStartTime(start);
     kernel.getKernelInfo();
     
     SimulationKernel & same_kernel = SimulationKernel::getSimulator();
     std::cout <<"\n\nKernel Address: " << &same_kernel << std::endl;
     same_kernel.getKernelInfo();
     
     cout << "\n\nTesting Registering of Agents with Kernel \n" << endl;
     
     AgentOne a1(one);
     AgentTwo a2(two);
     
     kernel.registerAgent(&a1);
     kernel.registerAgent(&a2);
     
     //lets set the start and end time
     kernel.setStartTime(0);
     kernel.setStopTime(100);
     
     //Lets make some events
     Event e1(one,two,t1,t3), e2(one,two,t2,t3), e3(one,two,t1,t3);
     //kernel.scheduler.scheduleEvent(&e1);
     //kernel.scheduler.scheduleEvent(&e2);
     //kernel.scheduler.scheduleEvent(&e3);
     
     //cout << "\n\nTesting Getting of Events from Scheduler \n" << endl;
     //EventContainer * events = kernel.scheduler.getNextEvents(two);
     
     ///cout << "List of events should be of Size 2: "<< events->size() << endl;
     
     //delete events;
     
     cout << "\n\nTesting Kernel Start \n" << endl;
     kernel.start();
     
     cout << "\n\n The SIMULATION has ENDED!!!! \n" << endl;
    return (EXIT_SUCCESS);
    
}//end main

