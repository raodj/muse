/* 
 * File:   Agent.h
 * Author: gebremr
 *
 * Created on November 16, 2008, 8:09 PM
 */

#ifndef _AGENT_H
#define	_AGENT_H

#include "DataTypes.h"
#include "Event.h"
#include "SimulationKernel.h"

namespace muse{

class Agent {
    
public:
    explicit Agent(AgentID &);
    virtual void initialize();
    virtual void finalize();
    virtual void executeTask(EventContainer *);
    const AgentID& getAgentID();
    bool scheduleEvent( Event *e);
protected:
    muse::Time _LVT;
    muse::AgentID _myID;

};


}
#endif	/* _AGENT_H */

