#include "AgentOne.h"
#include <iostream>

AgentOne::AgentOne(AgentID & id) : Agent(id)
{}


void
AgentOne::initialize(){
    std::cout << "AgentOne Is Initializing...." << std::endl;
    AgentID one=1, two=2;
    Time t1 = 1, t2=2, t3=3;
    Event e1(one,two,t1,t3), e2(one,two,t2,t3), e3(one,two,t1,t3);
    this->scheduleEvent(&e1);
    this->scheduleEvent(&e2);
    this->scheduleEvent(&e3);
}


void
AgentOne::executeTask(EventContainer * events){
    //should send event for agenttwo here
    std::cout << "AgentOne Is executing task...." << std::endl; 
    AgentID one=1, two=2;
    Time t1 = 1, t2=2, t3=3;
    Event e1(one,two,t1,t3);
    this->scheduleEvent(&e1);
}

void
AgentOne::finalize(){
    std::cout << "AgentOne Is finalizing...." << std::endl;
}
