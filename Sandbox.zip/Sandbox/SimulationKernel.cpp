#include "SimulationKernel.h"
using namespace muse;

SimulationKernel::SimulationKernel(Time & lgvt, SimulatorID & myID): _LGVT(lgvt), _myID(myID){}

bool 
SimulationKernel::registerAgent( Agent *agent){
    //add to the agents list
    if (scheduler.addAgentToScheduler(agent->getAgentID())){
        allAgents.insert(agent);
        return true;
    }//end if
    return false;
}

const AgentContainer& 
SimulationKernel::getRegisteredAgents(){
    return allAgents;
}

 SimulationKernel& 
SimulationKernel::getSimulator(){
    Time startGVT = 0;SimulatorID myID = 1;
    static SimulationKernel kernel(startGVT,myID);
    return kernel;
}
 
 bool 
 SimulationKernel::scheduleEvent( Event *e){
     return scheduler.scheduleEvent(e);
 }

void 
SimulationKernel::start(){
    AgentContainer::iterator it;
    //loop for the initialization
    for (it=allAgents.begin(); it != allAgents.end(); ++it){
        (*it)->initialize();
    }//end for
    
    //BIG loop for event processing 
    EventContainer *events = NULL;
    //while(true){
        for (it=allAgents.begin(); it != allAgents.end(); ++it){
            events = scheduler.getNextEvents((*it)->getAgentID());
            if (events != NULL){
                //this means we have events to process
                (*it)->executeTask(events);
            }//end if
            //(*it)->initialize();
        }//end for
    //}//end BIG loop
    //since we are done with the events pointer time to delete
    delete events;
    
    //loop for the finalization
    for (it=allAgents.begin(); it != allAgents.end(); ++it){
        (*it)->finalize();
    }//end for
}//end start

void 
SimulationKernel::setStartTime(const Time & startTime){
    _startTime = startTime;
}

void 
SimulationKernel::setStopTime(const Time & stopTime){
    _endTime = stopTime;
}

const Time& 
SimulationKernel::getTime(){
    return _LGVT;
}

const Time& 
SimulationKernel::getStartTime(){
    return _startTime;
}

const Time& 
SimulationKernel::getEndTime(){
    return _endTime;
}
void
SimulationKernel::getKernelInfo(){
    std::cout << "Simulator ID: " << this->_myID<< std::endl;
    std::cout << "Simulator Start Time: " << this->_startTime<< std::endl;
    std::cout << "Simulator End Time: " << this->_endTime<< std::endl;
    std::cout << "Simulator Current LGVT: " << this->_LGVT<< std::endl;
}
