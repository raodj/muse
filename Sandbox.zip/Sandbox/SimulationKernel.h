/* 
 * File:   SimulationKernel.h
 * Author: gebremr
 *
 * Created on November 16, 2008, 7:29 PM
 */

#ifndef _SIMULATIONKERNEL_H
#define	_SIMULATIONKERNEL_H

#include "Agent.h"
#include "Scheduler.h"
#include "Event.h"

namespace muse{

class SimulationKernel {
    
   public: 
       
        void getKernelInfo(); 
       
	bool registerAgent(  Agent *agent);
        
	const AgentContainer& getRegisteredAgents();
        
        static SimulationKernel& getSimulator();
        bool scheduleEvent( Event *e);

        void start();

	void setStartTime(const Time & startTime);

	void setStopTime(const Time & stopTime);

        const Time& getTime();
        
        const Time& getStartTime();
        
        const Time& getEndTime();
protected:
        //the ctor method, must be private (singleton pattern)
	SimulationKernel(Time &, SimulatorID&);
        SimulationKernel(const SimulationKernel &);
        SimulationKernel& operator=(const SimulationKernel&);
        
private:
        //used to contain all agents registered to this simulator
	AgentContainer allAgents;
        //usually the MPI_Rank, otherwise a globally unique id for the simulator. 
	SimulatorID _myID;
        Time _LGVT, _startTime, _endTime;
        Scheduler scheduler;
};



}
#endif	/* _SIMULATIONKERNEL_H */

