#include "AgentTwo.h"
#include <iostream>

AgentTwo::AgentTwo(AgentID & id) : Agent(id)
{}


void
AgentTwo::initialize(){
    std::cout << "AgentTwo Is Initializing...." << std::endl;
    AgentID one=1, two=2;
    Time t1 = 1, t2=2, t3=3;
    Event e1(two,one,t1,t3), e2(two,one,t2,t3), e3(two,one,t1,t3);
    this->scheduleEvent(&e1);
    this->scheduleEvent(&e2);
    this->scheduleEvent(&e3);
}


void
AgentTwo::executeTask(EventContainer * events){
    std::cout << "AgentTwo Is executing task...." << std::endl; 
    AgentID one=1, two=2;
    Time t1 = 1, t2=2, t3=3;
    Event e1(two,one,t1,t3);
    this->scheduleEvent(&e1);
}

void
AgentTwo::finalize(){
    std::cout << "AgentTwo Is finalizing...." << std::endl;
}
