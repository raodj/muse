/* 
 * File:   AgentTwo.h
 * Author: gebremr
 *
 * Created on November 17, 2008, 10:04 AM
 */

#ifndef _AGENTTWO_H
#define	_AGENTTWO_H

#include "Agent.h"
#include "DataTypes.h"

using namespace muse;

class AgentTwo : public Agent {
    
public:
    AgentTwo(AgentID &);
     void initialize();
     void finalize();
     void executeTask(EventContainer *);
};

#endif	/* _AGENTTWO_H */

